# Rando!

This is a simple random logs app to accompany the K8S course in develeap.
It'll write a number of random logs (containing a color and a number) at a defined interval.

No worries, we'll get you some logs!